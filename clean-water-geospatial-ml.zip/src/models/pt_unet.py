
from __future__ import annotations
import torch
import torch.nn as nn


class UNet(nn.Module):
    def __init__(self, in_ch: int = 4, classes: int = 5):
        super().__init__()
        self.enc1 = nn.Sequential(
            nn.Conv2d(in_ch, 64, 3, padding=1), nn.ReLU(),
            nn.Conv2d(64, 64, 3, padding=1), nn.ReLU()
        )
        self.pool = nn.MaxPool2d(2)
        self.dec1 = nn.Sequential(
            nn.Conv2d(64, 32, 3, padding=1), nn.ReLU(),
            nn.Conv2d(32, 32, 3, padding=1), nn.ReLU()
        )
        self.final = nn.Conv2d(32, classes, 1)

    def forward(self, x):
        x1 = self.enc1(x)
        x2 = self.pool(x1)
        x3 = self.dec1(x2)
        return self.final(x3)

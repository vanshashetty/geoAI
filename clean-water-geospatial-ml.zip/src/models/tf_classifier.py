
from __future__ import annotations
from typing import Tuple
import tensorflow as tf
from tensorflow.keras import layers, models


def build_classifier(input_shape: Tuple[int, int, int] = (128, 128, 4), classes: int = 5) -> tf.keras.Model:
    model = models.Sequential([
        layers.Conv2D(32, (3,3), activation='relu', input_shape=input_shape),
        layers.MaxPooling2D((2,2)),
        layers.Conv2D(64, (3,3), activation='relu'),
        layers.MaxPooling2D((2,2)),
        layers.Flatten(),
        layers.Dense(128, activation='relu'),
        layers.Dense(classes, activation='softmax'),
    ])
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model


from __future__ import annotations
import numpy as np
import rasterio
from rasterio.transform import from_origin


def save_mask_geotiff(path: str, mask: np.ndarray, bbox, pixel_size: float = 10.0, crs: str = 'EPSG:4326') -> None:
    """Save single-band mask (H,W) as GeoTIFF using bbox (minLon,minLat,maxLon,maxLat).
    This uses a simplistic transform with top-left at (minLon, maxLat) and square pixels.
    """
    minx, miny, maxx, maxy = bbox
    width, height = mask.shape[1], mask.shape[0]
    transform = from_origin(minx, maxy, pixel_size/111320.0, pixel_size/111320.0)  # approx deg/pixel
    with rasterio.open(
        path, 'w', driver='GTiff', height=height, width=width, count=1,
        dtype=mask.dtype, crs=crs, transform=transform
    ) as dst:
        dst.write(mask, 1)


"""AOI helpers: parse AOI_BBOX env var into floats and build affine transforms."""
from __future__ import annotations
import os
from typing import Tuple


def get_aoi_bbox() -> Tuple[float, float, float, float]:
    bbox_str = os.getenv("AOI_BBOX", "77.5946,12.9716,77.6046,12.9816")
    parts = [p.strip() for p in bbox_str.split(",")]
    if len(parts) != 4:
        raise ValueError("AOI_BBOX must be minLon,minLat,maxLon,maxLat")
    return tuple(map(float, parts))  # type: ignore

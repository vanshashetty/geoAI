
"""Thin wrapper around sentinelhub. Optional dependency.
Replace placeholders with your credentials or skip and use GEE/local rasters.
"""
from __future__ import annotations
from typing import Optional, Tuple

try:
    from sentinelhub import (
        SHConfig,
        SentinelHubRequest,
        DataCollection,
        MimeType,
        bbox_to_dimensions,
        BBox,
        CRS,
    )
except Exception:  # pragma: no cover
    SHConfig = SentinelHubRequest = DataCollection = MimeType = bbox_to_dimensions = BBox = CRS = None  # type: ignore


def download_s2_rgbnir(
    bbox: Tuple[float, float, float, float], resolution: int = 10
):
    if SHConfig is None:
        raise RuntimeError("sentinelhub is not installed; use GEE or local rasters")
    config = SHConfig()
    evalscript = """
    //VERSION=3
    function setup() {
      return { input: ["B02","B03","B04","B08"], output: { bands: 4 } };
    }
    function evaluatePixel(s) { return [s.B02, s.B03, s.B04, s.B08]; }
    """
    bbox_obj = BBox(bbox=bbox, crs=CRS.WGS84)
    size = bbox_to_dimensions(bbox_obj, resolution=resolution)
    request = SentinelHubRequest(
        data_folder="data/sentinel",
        evalscript=evalscript,
        input_data=[SentinelHubRequest.input_data(DataCollection.SENTINEL2_L2A)],
        responses=[SentinelHubRequest.output_response("default", MimeType.TIFF)],
        bbox=bbox_obj,
        size=size,
        config=config,
    )
    data = request.get_data()[0]  # (H,W,4)
    return data

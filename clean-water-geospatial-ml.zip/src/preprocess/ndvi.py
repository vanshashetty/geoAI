
from __future__ import annotations
import numpy as np


def compute_ndvi(b08: np.ndarray, b04: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    """Compute NDVI = (NIR - RED) / (NIR + RED + eps).
    Expects arrays scaled to [0, 1] or reflectance values.
    """
    return (b08 - b04) / (b08 + b04 + eps)


def stack_rgb_ndvi(b02: np.ndarray, b03: np.ndarray, b04: np.ndarray, ndvi: np.ndarray) -> np.ndarray:
    """Stack B02,B03,B04,NDVI into (H,W,4)."""
    return np.stack([b02, b03, b04, ndvi], axis=-1)

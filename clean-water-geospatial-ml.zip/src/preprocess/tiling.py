
from __future__ import annotations
import numpy as np
from typing import Iterator, Tuple


def tiles(img: np.ndarray, tile: int = 128) -> Iterator[Tuple[int,int,np.ndarray]]:
    """Yield (row, col, patch) tiles of size tile x tile from (H,W,C)."""
    H, W = img.shape[:2]
    for r in range(0, H, tile):
        for c in range(0, W, tile):
            yield r, c, img[r:r+tile, c:c+tile]


#!/usr/bin/env python
"""Export a dummy segmentation mask as GeoTIFF to validate pipeline end-to-end."""
import os
import numpy as np
from src.data.aoi import get_aoi_bbox
from src.exports.geotiff_exporter import save_mask_geotiff

H = W = int(os.getenv('TILE_SIZE', '128'))
mask = np.random.randint(0, 5, (H, W)).astype('uint8')

bbox = get_aoi_bbox()

os.makedirs('outputs', exist_ok=True)
path = 'outputs/landcover_prediction.tif'
save_mask_geotiff(path, mask, bbox)
print(f"Saved {path}")

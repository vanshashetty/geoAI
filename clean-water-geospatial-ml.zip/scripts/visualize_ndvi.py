
#!/usr/bin/env python
"""Generate a synthetic NDVI image preview for smoke testing visualization pipeline."""
import os
import numpy as np
import matplotlib.pyplot as plt

H = W = int(os.getenv('TILE_SIZE', '128'))
B04 = np.clip(np.random.rand(H, W), 0, 1)
B08 = np.clip(np.random.rand(H, W), 0, 1)

NDVI = (B08 - B04) / (B08 + B04 + 1e-6)

fig, ax = plt.subplots(1, 2, figsize=(8,4))
ax[0].imshow(np.stack([B04, B04*0.7, B04*0.3], axis=-1))
ax[0].set_title('Synthetic RGB')
ax[0].axis('off')
ax[1].imshow(NDVI, cmap='RdYlGn')
ax[1].set_title('NDVI')
ax[1].axis('off')
os.makedirs('outputs', exist_ok=True)
plt.savefig('outputs/ndvi_preview.png', dpi=120, bbox_inches='tight')
print('Saved outputs/ndvi_preview.png')

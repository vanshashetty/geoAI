
import numpy as np
from src.preprocess.ndvi import compute_ndvi

def test_compute_ndvi_range():
    red = np.array([[0.2, 0.3]], dtype=float)
    nir = np.array([[0.6, 0.1]], dtype=float)
    ndvi = compute_ndvi(nir, red)
    assert ndvi.shape == red.shape
    assert np.isfinite(ndvi).all()
    assert (ndvi <= 1.0 + 1e-6).all() and (ndvi >= -1.0 - 1e-6).all()

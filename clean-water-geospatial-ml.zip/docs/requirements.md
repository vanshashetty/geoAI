# Requirements — Geospatial Deep Learning for Clean Water & Land Cover

## 1) Project Overview
This repository delivers an end‑to‑end workflow that uses **TensorFlow** (classification) and **PyTorch** (segmentation) on Sentinel‑2 imagery, computes **NDVI**, exports **GeoTIFF** outputs for **QGIS**, and optionally publishes to **Google Earth Engine (GEE)**. It also includes a GIS‑driven “clean water source” **ranking** prototype using buffers/overlays and environmental features.

### Core Scenarios
- Land cover classification (e.g., Urban, Water, Forest, Agriculture) with TensorFlow.
- Semantic segmentation via a lightweight U‑Net in PyTorch.
- NDVI computation from B08 and B04 to improve accuracy and visualization.
- Export predictions as GeoTIFF for geospatial tools; integrate with QGIS and GEE.
- Optional: geospatial logic to identify and **rank** potentially clean water sources using land‑use, buffers, and protected areas.

## 2) Goals & Non‑Goals
**Goals**
- Reproducible pipeline to fetch Sentinel‑2 (RGB + NIR), preprocess, train simple models, and visualize/export results.
- Pluggable data layer (Sentinel Hub API or GEE) with minimal code edits.
- GIS‑first outputs (GeoTIFF, Shapefile) compatible with QGIS.
- Optional “clean water” ranking demo using simple features (NDVI, distances, protected areas, elevation).

**Non‑Goals**
- Not a production‑grade water safety certification tool; this is a research/POC pipeline.
- Not a fully automated data governance or labeling platform.

## 3) Functional Requirements
1. **Data Acquisition**
   - Download Sentinel‑2 L2A bands (B02, B03, B04, B08) for an AOI via **Sentinel Hub** or use **GEE** collections.
2. **Preprocessing**
   - Scale/normalize, stack RGB + NDVI; preview RGB and NDVI maps.
3. **Modeling**
   - **TF CNN** classifier (4‑channel input: RGB+NDVI) for 4–5 classes.
   - **PyTorch U‑Net** (4‑channel input) for land cover segmentation; basic training loop.
4. **Export**
   - Save predictions as **GeoTIFF** with correct CRS/transform.
5. **GIS Integration**
   - QGIS: open and style GeoTIFF; GEE: upload asset and visualize tiles.
6. **Water Source Ranking (optional)**
   - Ingest hydrology/land‑use/protected area layers; compute simple composite score and export ranked Shapefile.

## 4) Non‑Functional Requirements
- **Reproducibility**: notebooks/scripts runnable on local or Colab.
- **Modularity**: data, models, and exporters are decoupled to swap providers or models.
- **Interoperability**: outputs conform to common GIS formats (GeoTIFF, Shapefile).
- **Performance**: demo‑scale (patch‑based) training; large‑area processing can be offloaded to GEE.

## 5) Data Requirements
- **Inputs**
  - Sentinel‑2 L2A: B02 (Blue), B03 (Green), B04 (Red), B08 (NIR).
  - Optional GIS layers: rivers/lakes, urban/industrial zones, protected areas, DEM.
- **Derived**
  - NDVI = (B08 − B04) / (B08 + B04 + ε).
- **Labels**
  - Example classes for demo: {Water, Forest/Green, Urban/Bare, Agriculture, Other}.

## 6) Environments & Dependencies
- **Python** ≥ 3.9
- **Core Libraries**: `tensorflow`, `torch`, `torchvision`, `numpy`, `matplotlib`, `rasterio`, `geopandas`, `shapely`, `folium`
- **EO Access**: `sentinelhub` (optional) and/or `earthengine-api` (optional)
- **GPU** (optional): Colab / local CUDA for faster training

> See `environment.yml` or `requirements.txt` for pinned versions.

## 7) Configuration
Create `.env` or use environment variables:
- `SENTINELHUB_INSTANCE_ID`
- `SENTINELHUB_CLIENT_ID`
- `SENTINELHUB_CLIENT_SECRET`
- `AOI_BBOX` (minLon,minLat,maxLon,maxLat)
- `GEE_ASSET_ID` (optional)

## 8) Usage (Typical Flow)
1. **Download & Preprocess** — `notebooks/01_download_preprocess.ipynb`
2. **Train TF Classifier** — `notebooks/02_tf_classification.ipynb`
3. **Train PyTorch U‑Net** — `notebooks/03_pt_unet_segmentation.ipynb`
4. **Export GeoTIFF** — `scripts/export_geotiff.py`
5. **QGIS/GEE** — load GeoTIFF in QGIS or upload to GEE
6. **(Optional) Clean Water Ranking** — `notebooks/04_clean_water_ranking.ipynb`

## 9) Acceptance Criteria
- NDVI map and RGB preview for the AOI
- TF classifier trains and reports basic metrics
- PyTorch U‑Net outputs a georeferenced GeoTIFF mask
- QGIS opens the GeoTIFF; GEE visualizes tiles
- Optional: ranked sources Shapefile generated

## 10) Risks & Constraints
- Credentials required for real data pulls
- Satellite scenes are large (tiling needed)
- Labels may be synthetic unless you provide ground truth

## 11) Repository Structure (Proposed)
```
.
├─ notebooks/
├─ scripts/
├─ data/ (gitignored)
├─ models/ (saved weights)
├─ docs/
├─ src/
├─ tests/
└─ .github/workflows/
```

## 12) Licensing & Attribution
- Add a permissive license (e.g., MIT) and cite any third‑party data sources used.
